function changeAlignmentButtonPrelims(){
	

	var text = document.getElementById("Prelims").style.transition="all .5s ease";
	var text = document.getElementById("Prelims").style.transform = "translateY(10px)";	
	var text = document.getElementById("Prelims-Button").style["boxShadow"] = "0 20px 30px -10px";
		
}

	
	
function backToNormalStyleButtonPrelims(){
	
	var text = document.getElementById("Prelims-Button").style["boxShadow"]="0 0 0px ";	
	var text = document.getElementById("Prelims").style.transform = "translateY(0px)"
	
}

	function changeAlignmentButtonMidterms(){
	
	var text = document.getElementById("Midterms").style.transition="all .5s ease";
	var text = document.getElementById("Midterms").style.transform = "translateY(10px)";	
	var text = document.getElementById("Midterms-Button").style["boxShadow"] = "0 20px 30px -10px";
	
}

	
	
function backToNormalStyleButtonMidterms(){
		
	var text = document.getElementById("Midterms-Button").style["boxShadow"]="0 0 0px ";	
	var text = document.getElementById("Midterms").style.transform = "translateY(0px)"
	
}

	function changeAlignmentButtonFinals(){
	
	var text = document.getElementById("Finals").style.transition="all .5s ease";
	var text = document.getElementById("Finals").style.transform = "translateY(10px)";	
	var text = document.getElementById("Finals-Button").style["boxShadow"] = "0 20px 30px -10px";	
}

	
	
function backToNormalStyleButtonFinals(){
	
	var text = document.getElementById("Finals-Button").style["boxShadow"]="0 0 0px ";	
	var text = document.getElementById("Finals").style.transform = "translateY(0px)";
	
}

	