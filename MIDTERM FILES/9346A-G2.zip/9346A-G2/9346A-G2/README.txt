	To open the Landing page, open the html file named index.html. The landing page consist an icon of a rocket where if you click the rocket it will go to a page that will display three(3)columns which are Prelims, Midterms and Finals. 

	If you click the Prelims button, you will see the different topics and it's content. And if you are in the Prelims page and you want to go back to the landing page, just click the icon start in the upper left corner of the page.

	If you click the Midterms button, you will see the different topics and it's content. And if you are in the Midterms page and you would like to go back to the landing page, just click the icon star in the upper left corner of the page.

	The Finals button is not yet working since we don't have notes regarding the topics to be discussed on the Finals. If you try to click the Finals buttons, the "Page Not Found" will display on your web browser. 
